#!/usr/bin/env bash
# build.sh — compila o projeto 3DS dentro do Docker, corrigindo problemas
# conhecidos automaticamente e dando um relatório claro no final.

set -uo pipefail

say()  { echo -e "\n>>> $1"; }
fail() { echo -e "\n❌ ERRO: $1\n"; exit 1; }
ok()   { echo -e "✅ $1"; }

# ---------------------------------------------------------------------------
# 1) localizar a pasta do projeto (build3ds) a partir de /workspaces
# ---------------------------------------------------------------------------
say "Procurando a pasta do projeto..."
PROJECT_DIR=$(find /workspaces -maxdepth 4 -type d -name build3ds 2>/dev/null | head -1)
[ -z "$PROJECT_DIR" ] && fail "Não achei a pasta 'build3ds'. Confirma que já deu 'unzip' do projeto."
cd "$PROJECT_DIR" || fail "Não consegui entrar em $PROJECT_DIR"
ok "Projeto em: $PROJECT_DIR"

[ -f Makefile ] || fail "Makefile não encontrado dentro de $PROJECT_DIR"

# ---------------------------------------------------------------------------
# 2) checar Docker
# ---------------------------------------------------------------------------
say "Checando Docker..."
command -v docker >/dev/null 2>&1 || fail "Docker não encontrado neste Codespace."
docker image inspect devkitpro/devkitarm >/dev/null 2>&1 || {
    say "Imagem devkitpro/devkitarm não está local, baixando..."
    docker pull devkitpro/devkitarm || fail "Não consegui baixar a imagem Docker."
}
ok "Docker e imagem disponíveis."

# ---------------------------------------------------------------------------
# 3) corrigir automaticamente bugs conhecidos no Makefile
# ---------------------------------------------------------------------------
say "Aplicando correções conhecidas no Makefile (se necessário)..."
python3 - << 'PYEOF'
import re

path = "Makefile"
with open(path) as f:
    content = f.read()
original = content

# bug #1: flags erradas do tex3ds (-i/-h não existem nesta versão; o certo é
# arquivo de entrada posicional + -H maiúsculo para o header)
bad_patterns = [
    "tex3ds -i $(f) -h $(GFXBUILD)/$(basename $(notdir $(f))).h -o $(GFXBUILD)/$(basename $(notdir $(f))).t3x;",
]
fixed_line = "tex3ds -H $(GFXBUILD)/$(basename $(notdir $(f))).h -o $(GFXBUILD)/$(basename $(notdir $(f))).t3x $(f);"

changed = False
for bad in bad_patterns:
    if bad in content:
        content = content.replace(bad, fixed_line)
        changed = True

if changed:
    with open(path, "w") as f:
        f.write(content)
    print("Makefile: bug do tex3ds corrigido.")
else:
    if "tex3ds -H" in content:
        print("Makefile: já estava corrigido, nada a fazer.")
    else:
        print("Aviso: não encontrei o padrão esperado nem a versão corrigida.")
        print("Pode ser uma variação do Makefile — segue mesmo assim.")
PYEOF

# ---------------------------------------------------------------------------
# 4) limpar qualquer build anterior com erro (resíduos quebrados)
# ---------------------------------------------------------------------------
say "Limpando build anterior (se existir)..."
docker run --rm -v "$(pwd):/project" -w /project devkitpro/devkitarm \
    bash -c "make clean >/dev/null 2>&1; rm -rf romfs build *.elf *.3dsx *.smdh *.cia *.3ds" \
    || echo "(nada para limpar, ou make clean falhou silenciosamente — ok, seguimos)"
ok "Limpeza concluída."

# ---------------------------------------------------------------------------
# 5) compilar dentro do Docker, salvando log completo
# ---------------------------------------------------------------------------
say "Compilando (isso pode levar 1-2 minutos)..."
LOG="build.log"
docker run --rm -v "$(pwd):/project" -w /project devkitpro/devkitarm make 2>&1 | tee "$LOG"
BUILD_EXIT=${PIPESTATUS[0]}

# ---------------------------------------------------------------------------
# 6) diagnóstico do resultado
# ---------------------------------------------------------------------------
say "Resultado:"

if [ "$BUILD_EXIT" -ne 0 ] || grep -qiE "error|no such file|undefined reference|fatal error" "$LOG"; then
    echo ""
    echo "❌ A compilação encontrou problemas. Últimas linhas relevantes do log:"
    echo "------------------------------------------------------------"
    grep -iE "error|warning|no such file|undefined reference|fatal error" "$LOG" | tail -30
    echo "------------------------------------------------------------"
    echo ""
    echo "O log completo está salvo em: $PROJECT_DIR/build.log"
    echo "Cola aqui as linhas de erro acima (ou o build.log inteiro) que eu ajusto o código."
    exit 1
fi

if [ -f "hakucho-no-tenshi.3dsx" ]; then
    SIZE=$(du -h "hakucho-no-tenshi.3dsx" | cut -f1)
    ok "Build concluído! hakucho-no-tenshi.3dsx gerado ($SIZE)."
    echo ""
    echo "Esse arquivo já roda no Citra/Azahar ou via Homebrew Launcher num 3DS."
    echo "Pra baixar pro seu iPad: clica com o botão direito (ou toque longo) no"
    echo "arquivo no painel de arquivos do VS Code → Download."
else
    fail "O make terminou sem erro aparente, mas hakucho-no-tenshi.3dsx não foi criado. Cola o build.log aqui."
fi
