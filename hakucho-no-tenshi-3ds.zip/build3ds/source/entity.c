#include "game.h"
#include <math.h>
#include <stdlib.h>

static float frand01(void) { return (rand() % 1000) / 1000.0f; }

static void base_for_team(Team team, float *bx, float *by)
{
    float tx = COLS * 0.5f;
    float ty = (team == TEAM_ORANGE) ? ROWS * 0.82f : ROWS * 0.18f;
    float best = 1e9f;
    float rx = TOP_W / 2.0f, ry = TOP_H / 2.0f;

    for (int y = 0; y < ROWS; y++) {
        for (int x = 0; x < COLS; x++) {
            if (g_map[y][x] == TILE_WATER) continue;
            float d = (x - tx) * (x - tx) + (y - ty) * (y - ty);
            if (d < best) {
                best = d;
                rx = x * TILE + TILE * 0.5f;
                ry = y * TILE + TILE * 0.5f;
            }
        }
    }
    *bx = rx; *by = ry;
}

void entity_init(Entity *e, Team team, int skin, int isPlayer)
{
    e->team = team;
    e->skin = skin;
    e->isPlayer = isPlayer;
    e->face = 1.0f;
    e->animFrame = 0;
    e->animTimer = 0.0f;
    e->moving = 0;
    e->retargetTimer = 0.0f;
    entity_spawn(e);
}

void entity_spawn(Entity *e)
{
    float bx, by;
    base_for_team(e->team, &bx, &by);
    e->x = bx; e->y = by;
    e->hp = MAX_HP;
    e->dead = 0;
    e->invuln = 1.2f;
}

void entity_move(Entity *e, float dx, float dy, float dt)
{
    float m = sqrtf(dx * dx + dy * dy);
    e->moving = (m > 0.05f);
    if (!e->moving) return;

    dx /= m; dy /= m;
    float spd = 58.0f;

    Team here = ink_owner_at_px(e->x, e->y);
    if (here != TEAM_NONE && here != e->team) spd *= 0.5f; /* slow in enemy ink */

    float nx = e->x + dx * spd * dt;
    float ny = e->y + dy * spd * dt;
    if (map_is_land_px(nx, e->y)) e->x = nx;
    if (map_is_land_px(e->x, ny)) e->y = ny;
    if (fabsf(dx) > 0.1f) e->face = (dx < 0) ? -1.0f : 1.0f;

    e->animTimer += dt;
    if (e->animTimer > 0.09f) {
        e->animTimer = 0.0f;
        e->animFrame = (e->animFrame + 1) % 8;
    }

    /* leaves a trail of ink under its feet while moving */
    ink_paint(e->x, e->y + 8.0f, 10.0f, e->team);
}

void entity_update_player(Entity *e, float dt)
{
    if (e->dead) return;

    circlePosition cp;
    hidCircleRead(&cp);
    float dx = cp.dx / 156.0f;
    float dy = -cp.dy / 156.0f; /* circle pad Y is inverted vs screen Y */

    if (fabsf(dx) < 0.18f) dx = 0.0f;
    if (fabsf(dy) < 0.18f) dy = 0.0f;

    entity_move(e, dx, dy, dt);
}

void entity_update_bot(Entity *e, Entity all[], int count, float dt)
{
    if (e->dead) return;

    e->retargetTimer -= dt;

    Entity *foe = NULL;
    float bestD = 140.0f * 140.0f;
    for (int i = 0; i < count; i++) {
        Entity *o = &all[i];
        if (o == e || o->dead || o->team == e->team) continue;
        float d = (o->x - e->x) * (o->x - e->x) + (o->y - e->y) * (o->y - e->y);
        if (d < bestD) { bestD = d; foe = o; }
    }

    int reached = (fabsf(e->targetX - e->x) < 20.0f && fabsf(e->targetY - e->y) < 20.0f);
    if (e->retargetTimer <= 0.0f || reached) {
        for (int tries = 0; tries < 25; tries++) {
            float rx = frand01() * TOP_W;
            float ry = frand01() * TOP_H;
            if (map_is_land_px(rx, ry)) { e->targetX = rx; e->targetY = ry; break; }
        }
        e->retargetTimer = 1.2f + frand01() * 1.6f;
    }

    float tx, ty;
    if (foe) { tx = foe->x; ty = foe->y; }
    else     { tx = e->targetX; ty = e->targetY; }

    float dx = tx - e->x, dy = ty - e->y;
    float d = sqrtf(dx * dx + dy * dy);
    if (d < 1.0f) d = 1.0f;
    dx /= d; dy /= d;

    if (foe && bestD < 70.0f * 70.0f) { dx *= -0.4f; dy *= -0.4f; } /* keep a little distance */

    entity_move(e, dx, dy, dt);
}

void entity_tick_status(Entity *e, float dt)
{
    if (e->invuln > 0.0f) e->invuln -= dt;

    if (e->dead) {
        e->respawnTimer -= dt;
        if (e->respawnTimer <= 0.0f) entity_spawn(e);
        return;
    }

    Team here = ink_owner_at_px(e->x, e->y);
    if (here == e->team) {
        e->hp += 0.4f * dt;
        if (e->hp > MAX_HP) e->hp = MAX_HP;
    } else if (here != TEAM_NONE) {
        e->hp -= 0.5f * dt;
        if (e->hp <= 0.0f && e->invuln <= 0.0f) {
            e->hp = 0.0f; e->dead = 1; e->respawnTimer = 3.0f;
        }
    }
}

void entity_damage(Entity *e, float amount)
{
    if (e->dead || e->invuln > 0.0f) return;
    e->hp -= amount;
    if (e->hp <= 0.0f) {
        e->hp = 0.0f; e->dead = 1; e->respawnTimer = 3.0f;
    }
}
