#include "game.h"
#include <stdlib.h>
#include <string.h>

#include "tiles.h"
#include "chars.h"
#include "hp.h"

/* ---------------- shared graphics ---------------- */
C2D_SpriteSheet g_tilesSheet;
C2D_SpriteSheet g_charsSheet;
C2D_SpriteSheet g_hpSheet;

C2D_Image g_tileImg[4];
C2D_Image g_charIdle[4][2];
C2D_Image g_charWalk[4][8];
C2D_Image g_hpFull;
C2D_Image g_hpEmpty;

typedef enum { ST_TITLE, ST_PLAY, ST_END } GameState;

static Entity s_ents[ENTITY_COUNT];
static float  s_timeLeft;
static int    s_covO, s_covB;
static GameState s_state = ST_TITLE;

static void load_graphics(void)
{
    g_tilesSheet = C2D_SpriteSheetLoad("romfs:/gfx/tiles.t3x");
    g_charsSheet = C2D_SpriteSheetLoad("romfs:/gfx/chars.t3x");
    g_hpSheet    = C2D_SpriteSheetLoad("romfs:/gfx/hp.t3x");

    g_tileImg[TILE_WATER] = C2D_SpriteSheetGetImage(g_tilesSheet, tiles_water_idx);
    g_tileImg[TILE_GRASS] = C2D_SpriteSheetGetImage(g_tilesSheet, tiles_grass_idx);
    g_tileImg[TILE_STONE] = C2D_SpriteSheetGetImage(g_tilesSheet, tiles_stone_idx);
    g_tileImg[TILE_SNOW]  = C2D_SpriteSheetGetImage(g_tilesSheet, tiles_snow_idx);

    g_charIdle[0][0] = C2D_SpriteSheetGetImage(g_charsSheet, chars_c0_idle0_idx);
    g_charIdle[0][1] = C2D_SpriteSheetGetImage(g_charsSheet, chars_c0_idle1_idx);
    g_charIdle[1][0] = C2D_SpriteSheetGetImage(g_charsSheet, chars_c1_idle0_idx);
    g_charIdle[1][1] = C2D_SpriteSheetGetImage(g_charsSheet, chars_c1_idle1_idx);
    g_charIdle[2][0] = C2D_SpriteSheetGetImage(g_charsSheet, chars_c2_idle0_idx);
    g_charIdle[2][1] = C2D_SpriteSheetGetImage(g_charsSheet, chars_c2_idle1_idx);
    g_charIdle[3][0] = C2D_SpriteSheetGetImage(g_charsSheet, chars_c3_idle0_idx);
    g_charIdle[3][1] = C2D_SpriteSheetGetImage(g_charsSheet, chars_c3_idle1_idx);

    g_charWalk[0][0] = C2D_SpriteSheetGetImage(g_charsSheet, chars_c0_walk0_idx);
    g_charWalk[0][1] = C2D_SpriteSheetGetImage(g_charsSheet, chars_c0_walk1_idx);
    g_charWalk[0][2] = C2D_SpriteSheetGetImage(g_charsSheet, chars_c0_walk2_idx);
    g_charWalk[0][3] = C2D_SpriteSheetGetImage(g_charsSheet, chars_c0_walk3_idx);
    g_charWalk[0][4] = C2D_SpriteSheetGetImage(g_charsSheet, chars_c0_walk4_idx);
    g_charWalk[0][5] = C2D_SpriteSheetGetImage(g_charsSheet, chars_c0_walk5_idx);
    g_charWalk[0][6] = C2D_SpriteSheetGetImage(g_charsSheet, chars_c0_walk6_idx);
    g_charWalk[0][7] = C2D_SpriteSheetGetImage(g_charsSheet, chars_c0_walk7_idx);

    g_charWalk[1][0] = C2D_SpriteSheetGetImage(g_charsSheet, chars_c1_walk0_idx);
    g_charWalk[1][1] = C2D_SpriteSheetGetImage(g_charsSheet, chars_c1_walk1_idx);
    g_charWalk[1][2] = C2D_SpriteSheetGetImage(g_charsSheet, chars_c1_walk2_idx);
    g_charWalk[1][3] = C2D_SpriteSheetGetImage(g_charsSheet, chars_c1_walk3_idx);
    g_charWalk[1][4] = C2D_SpriteSheetGetImage(g_charsSheet, chars_c1_walk4_idx);
    g_charWalk[1][5] = C2D_SpriteSheetGetImage(g_charsSheet, chars_c1_walk5_idx);
    g_charWalk[1][6] = C2D_SpriteSheetGetImage(g_charsSheet, chars_c1_walk6_idx);
    g_charWalk[1][7] = C2D_SpriteSheetGetImage(g_charsSheet, chars_c1_walk7_idx);

    g_charWalk[2][0] = C2D_SpriteSheetGetImage(g_charsSheet, chars_c2_walk0_idx);
    g_charWalk[2][1] = C2D_SpriteSheetGetImage(g_charsSheet, chars_c2_walk1_idx);
    g_charWalk[2][2] = C2D_SpriteSheetGetImage(g_charsSheet, chars_c2_walk2_idx);
    g_charWalk[2][3] = C2D_SpriteSheetGetImage(g_charsSheet, chars_c2_walk3_idx);
    g_charWalk[2][4] = C2D_SpriteSheetGetImage(g_charsSheet, chars_c2_walk4_idx);
    g_charWalk[2][5] = C2D_SpriteSheetGetImage(g_charsSheet, chars_c2_walk5_idx);
    g_charWalk[2][6] = C2D_SpriteSheetGetImage(g_charsSheet, chars_c2_walk6_idx);
    g_charWalk[2][7] = C2D_SpriteSheetGetImage(g_charsSheet, chars_c2_walk7_idx);

    g_charWalk[3][0] = C2D_SpriteSheetGetImage(g_charsSheet, chars_c3_walk0_idx);
    g_charWalk[3][1] = C2D_SpriteSheetGetImage(g_charsSheet, chars_c3_walk1_idx);
    g_charWalk[3][2] = C2D_SpriteSheetGetImage(g_charsSheet, chars_c3_walk2_idx);
    g_charWalk[3][3] = C2D_SpriteSheetGetImage(g_charsSheet, chars_c3_walk3_idx);
    g_charWalk[3][4] = C2D_SpriteSheetGetImage(g_charsSheet, chars_c3_walk4_idx);
    g_charWalk[3][5] = C2D_SpriteSheetGetImage(g_charsSheet, chars_c3_walk5_idx);
    g_charWalk[3][6] = C2D_SpriteSheetGetImage(g_charsSheet, chars_c3_walk6_idx);
    g_charWalk[3][7] = C2D_SpriteSheetGetImage(g_charsSheet, chars_c3_walk7_idx);

    g_hpFull  = C2D_SpriteSheetGetImage(g_hpSheet, hp_full_idx);
    g_hpEmpty = C2D_SpriteSheetGetImage(g_hpSheet, hp_empty_idx);
}

static void free_graphics(void)
{
    C2D_SpriteSheetFree(g_tilesSheet);
    C2D_SpriteSheetFree(g_charsSheet);
    C2D_SpriteSheetFree(g_hpSheet);
}

/* player = orange/skin0, ally bot = orange/skin1, two foe bots = blue/skin2,3 */
static void start_match(void)
{
    map_generate();
    entity_init(&s_ents[0], TEAM_ORANGE, 0, 1); /* player */
    entity_init(&s_ents[1], TEAM_ORANGE, 1, 0); /* ally bot   */
    entity_init(&s_ents[2], TEAM_BLUE,   2, 0); /* foe bot 1  */
    entity_init(&s_ents[3], TEAM_BLUE,   3, 0); /* foe bot 2  */

    /* small home splat so the match doesn't start at 0% */
    for (int i = 0; i < ENTITY_COUNT; i++) {
        ink_paint(s_ents[i].x, s_ents[i].y, 18.0f, s_ents[i].team);
    }

    s_timeLeft = MATCH_SECONDS;
    ink_coverage(&s_covO, &s_covB);
    s_state = ST_PLAY;
}

int main(int argc, char *argv[])
{
    gfxInitDefault();
    Result rc = romfsInit();
    if (R_FAILED(rc)) {
        /* romfs failed to mount: nothing we can draw without it, just exit cleanly */
        gfxExit();
        return 0;
    }

    C3D_Init(C3D_DEFAULT_CMDBUF_SIZE);
    C2D_Init(C2D_DEFAULT_MAX_OBJECTS);
    C2D_Prepare();

    C3D_RenderTarget *top    = C2D_CreateScreenTarget(GFX_TOP, GFX_LEFT);
    C3D_RenderTarget *bottom = C2D_CreateScreenTarget(GFX_BOTTOM, GFX_LEFT);

    g_textBuf = C2D_TextBufNew(4096);
    load_graphics();

    srand((unsigned int)osGetTime());

    u64 lastTick = osGetTime();

    while (aptMainLoop()) {
        hidScanInput();
        u32 kDown = hidKeysDown();
        if (kDown & KEY_START && s_state != ST_PLAY) {
            start_match();
        }

        u64 now = osGetTime();
        float dt = (now - lastTick) / 1000.0f;
        lastTick = now;
        if (dt > 0.05f) dt = 0.05f;
        if (dt < 0.0f)  dt = 0.0f;

        if (s_state == ST_PLAY) {
            s_timeLeft -= dt;

            entity_update_player(&s_ents[0], dt);
            for (int i = 1; i < ENTITY_COUNT; i++) {
                entity_update_bot(&s_ents[i], s_ents, ENTITY_COUNT, dt);
            }
            for (int i = 0; i < ENTITY_COUNT; i++) {
                entity_tick_status(&s_ents[i], dt);
            }

            ink_coverage(&s_covO, &s_covB);

            if (s_timeLeft <= 0.0f) {
                s_timeLeft = 0.0f;
                s_state = ST_END;
            }
        }

        C3D_FrameBegin(C3D_FRAME_SYNCDRAW);

        C2D_TargetClear(top, C2D_Color32(8, 18, 30, 255));
        C2D_SceneBegin(top);
        if (s_state == ST_TITLE) {
            render_title();
        } else if (s_state == ST_PLAY) {
            render_top(s_ents, ENTITY_COUNT);
        } else {
            render_top(s_ents, ENTITY_COUNT);
            render_end(s_covO, s_covB);
        }

        C2D_TargetClear(bottom, C2D_Color32(6, 18, 30, 255));
        C2D_SceneBegin(bottom);
        if (s_state != ST_TITLE) {
            render_bottom(&s_ents[0], s_timeLeft, s_covO, s_covB);
        }

        C3D_FrameEnd(0);
    }

    free_graphics();
    C2D_TextBufDelete(g_textBuf);
    C2D_Fini();
    C3D_Fini();
    romfsExit();
    gfxExit();
    return 0;
}
