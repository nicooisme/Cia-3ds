#include "game.h"
#include <stdio.h>
#include <math.h>

C2D_TextBuf g_textBuf;

static void draw_text(const char *str, float x, float y, float scale, u32 color)
{
    C2D_Text text;
    C2D_TextParse(&text, g_textBuf, str);
    C2D_TextOptimize(&text);
    C2D_DrawText(&text, C2D_WithColor, x, y, 0.5f, scale, scale, color);
}

static void draw_text_centered(const char *str, float cx, float y, float scale, u32 color)
{
    C2D_Text text;
    C2D_TextParse(&text, g_textBuf, str);
    C2D_TextOptimize(&text);
    float w, h;
    C2D_TextGetDimensions(&text, scale, scale, &w, &h);
    C2D_DrawText(&text, C2D_WithColor, cx - w * 0.5f, y, 0.5f, scale, scale, color);
}

/* ---------------- TOP SCREEN : the island + characters ---------------- */
void render_top(Entity all[], int count)
{
    C2D_TextBufClear(g_textBuf);

    /* base terrain */
    for (int y = 0; y < ROWS; y++) {
        for (int x = 0; x < COLS; x++) {
            C2D_DrawImageAt(g_tileImg[g_map[y][x]], x * TILE, y * TILE, 0.0f, NULL, 1.0f, 1.0f);
        }
    }

    /* ink overlay (only drawn over owned cells, semi-transparent) */
    for (int iy = 0; iy < INK_ROWS; iy++) {
        for (int ix = 0; ix < INK_COLS; ix++) {
            Team t = g_ink[iy][ix];
            if (t == TEAM_NONE) continue;
            u32 color = (t == TEAM_ORANGE)
                ? C2D_Color32(255, 122, 24, 140)
                : C2D_Color32(43, 140, 255, 140);
            C2D_DrawRectSolid(ix * INK_CELL, iy * INK_CELL, 0.3f, INK_CELL, INK_CELL, color);
        }
    }

    /* characters */
    for (int i = 0; i < count; i++) {
        Entity *e = &all[i];
        if (e->dead) continue;

        u32 ringColor = (e->team == TEAM_ORANGE)
            ? C2D_Color32(255, 122, 24, 110)
            : C2D_Color32(43, 140, 255, 110);
        C2D_DrawRectSolid(e->x - 12.0f, e->y + 5.0f, 0.25f, 24.0f, 6.0f, ringColor);

        C2D_Image img = e->moving
            ? g_charWalk[e->skin][e->animFrame]
            : g_charIdle[e->skin][e->animFrame % 2];

        /* flashes while invulnerable just after respawning */
        if (e->invuln > 0.0f && ((int)(e->invuln * 10.0f) % 2 == 0)) continue;

        C2D_DrawImageAt(img, e->x - 14.0f, e->y - 26.0f, 0.2f, NULL, 1.0f, 1.0f);
    }
}

/* ---------------- BOTTOM SCREEN : 5 hearts + timer + score ---------------- */
void render_bottom(Entity *player, float timeLeft, int covO, int covB)
{
    C2D_DrawRectSolid(0, 0, 0.0f, BOT_W, BOT_H, C2D_Color32(6, 18, 30, 255));

    /* 5 hearts, centered */
    int full = (int)ceilf(player->hp);
    if (full < 0) full = 0;
    if (full > 5) full = 5;

    float heartSize = 40.0f;
    float gap = 8.0f;
    float totalW = 5 * heartSize + 4 * gap;
    float startX = (BOT_W - totalW) * 0.5f;
    float heartY = 40.0f;

    for (int i = 0; i < 5; i++) {
        C2D_Image img = (i < full) ? g_hpFull : g_hpEmpty;
        float scale = heartSize / 96.0f; /* source hearts are ~96px square */
        C2D_DrawImageAt(img, startX + i * (heartSize + gap), heartY, 0.4f, NULL, scale, scale);
    }

    /* timer */
    int t = (int)(timeLeft > 0 ? timeLeft : 0);
    int mm = t / 60, ss = t % 60;
    char buf[16];
    snprintf(buf, sizeof(buf), "%d:%02d", mm, ss);
    draw_text_centered(buf, BOT_W * 0.5f, 110.0f, 1.4f, C2D_Color32(255, 255, 255, 255));

    /* score */
    char scoreBuf[48];
    snprintf(scoreBuf, sizeof(scoreBuf), "LARANJA %d%%   x   AZUL %d%%", covO, covB);
    draw_text_centered(scoreBuf, BOT_W * 0.5f, 160.0f, 0.8f, C2D_Color32(220, 235, 255, 255));

    draw_text_centered("Circle Pad: mover  -  pinta sozinho ao andar",
                        BOT_W * 0.5f, 200.0f, 0.55f, C2D_Color32(130, 170, 200, 255));
}

/* ---------------- TITLE / END overlays (drawn on TOP screen) ---------------- */
void render_title(void)
{
    C2D_DrawRectSolid(0, 0, 0.0f, TOP_W, TOP_H, C2D_Color32(8, 20, 35, 255));
    draw_text_centered("HAKUCHOU NO TENSHI", TOP_W * 0.5f, 70.0f, 1.3f, C2D_Color32(190, 230, 255, 255));
    draw_text_centered("guerra de tinta na ilha nevada", TOP_W * 0.5f, 105.0f, 0.7f, C2D_Color32(140, 190, 220, 255));
    draw_text_centered("START para comecar", TOP_W * 0.5f, 160.0f, 0.9f, C2D_Color32(255, 200, 110, 255));
}

void render_end(int covO, int covB)
{
    C2D_DrawRectSolid(0, 0, 0.0f, TOP_W, TOP_H, C2D_Color32(8, 20, 35, 235));

    const char *result;
    u32 color;
    if (covO > covB)      { result = "VOCE VENCEU!"; color = C2D_Color32(255, 210, 110, 255); }
    else if (covB > covO) { result = "VOCE PERDEU";  color = C2D_Color32(160, 200, 230, 255); }
    else                   { result = "EMPATE!";       color = C2D_Color32(255, 255, 255, 255); }

    draw_text_centered(result, TOP_W * 0.5f, 80.0f, 1.3f, color);

    char scoreBuf[48];
    snprintf(scoreBuf, sizeof(scoreBuf), "Laranja %d%%  x  Azul %d%%", covO, covB);
    draw_text_centered(scoreBuf, TOP_W * 0.5f, 120.0f, 0.9f, C2D_Color32(230, 240, 255, 255));

    draw_text_centered("START para jogar de novo", TOP_W * 0.5f, 170.0f, 0.8f, C2D_Color32(180, 210, 230, 255));
}
