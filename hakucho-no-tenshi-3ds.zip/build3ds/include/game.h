#ifndef GAME_H
#define GAME_H

#include <3ds.h>
#include <citro2d.h>
#include <citro3d.h>

/* ---------------- screen / grid sizes ---------------- */
#define TOP_W 400
#define TOP_H 240
#define BOT_W 320
#define BOT_H 240

#define TILE  16
#define COLS  25   /* 25*16 = 400 -> island fits the whole top screen */
#define ROWS  15   /* 15*16 = 240                                      */

#define INK_CELL 8 /* finer grid than visual tiles, for smoother turf % */
#define INK_COLS (TOP_W / INK_CELL)
#define INK_ROWS (TOP_H / INK_CELL)

#define MAX_HP 5.0f
#define MATCH_SECONDS 120.0f
#define ENTITY_COUNT 4

typedef enum { TILE_WATER = 0, TILE_GRASS, TILE_STONE, TILE_SNOW } TileType;
typedef enum { TEAM_NONE = 0, TEAM_ORANGE, TEAM_BLUE } Team;

typedef struct {
    float x, y;
    float face;            /* 1.0f or -1.0f, kept for future use */
    Team  team;
    int   skin;            /* 0..3, indexes the chars spritesheet group */
    float hp;
    int   dead;
    float respawnTimer;
    float invuln;
    int   animFrame;
    float animTimer;
    int   moving;
    int   isPlayer;
    float targetX, targetY; /* bot AI wander target */
    float retargetTimer;
} Entity;

/* ---------------- map / ink ---------------- */
extern TileType g_map[ROWS][COLS];
extern Team     g_ink[INK_ROWS][INK_COLS];

void  map_generate(void);
int   map_is_land_px(float x, float y);
TileType map_tile_at_px(float x, float y);

void  ink_paint(float x, float y, float radius, Team team);
Team  ink_owner_at_px(float x, float y);
void  ink_coverage(int *outOrangePct, int *outBluePct);

/* ---------------- entities ---------------- */
void entity_init(Entity *e, Team team, int skin, int isPlayer);
void entity_spawn(Entity *e);
void entity_move(Entity *e, float dx, float dy, float dt);
void entity_update_player(Entity *e, float dt);
void entity_update_bot(Entity *e, Entity all[], int count, float dt);
void entity_tick_status(Entity *e, float dt);
void entity_damage(Entity *e, float amount);

/* ---------------- shared graphics (loaded once in main.c) ---------------- */
extern C2D_SpriteSheet g_tilesSheet;
extern C2D_SpriteSheet g_charsSheet;
extern C2D_SpriteSheet g_hpSheet;

extern C2D_Image g_tileImg[4];        /* indexed by TileType   */
extern C2D_Image g_charIdle[4][2];    /* [skin][frame 0..1]    */
extern C2D_Image g_charWalk[4][8];    /* [skin][frame 0..7]    */
extern C2D_Image g_hpFull;
extern C2D_Image g_hpEmpty;

extern C2D_TextBuf g_textBuf;

/* ---------------- rendering ---------------- */
void render_top(Entity all[], int count);
void render_bottom(Entity *player, float timeLeft, int covO, int covB);
void render_title(void);
void render_end(int covO, int covB);

#endif
