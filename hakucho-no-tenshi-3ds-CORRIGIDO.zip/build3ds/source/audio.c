#include "game.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* Background music: raw 16-bit mono PCM @ 11025Hz, baked from the user's
   mp3 at build time, trimmed to ~20s loop -- kept small on purpose to fit
   comfortably in the Old 3DS's limited linear memory (see romfs/audio/bgm.pcm). */
#define BGM_SAMPLE_RATE  11025.0f
#define BGM_CHANNEL      0

static s16        *s_bgmBuffer  = NULL;
static ndspWaveBuf s_bgmWaveBuf;
static u32          s_bgmSamples = 0;
static bool         s_bgmReady   = false;
static bool         s_ndspReady  = false;
char g_audioStatus[48] = "audio: nao iniciado";

void audio_init(void)
{
    Result rc = ndspInit();
    if (R_FAILED(rc)) {
        snprintf(g_audioStatus, sizeof(g_audioStatus), "audio: ndspInit falhou (0x%lx)", (unsigned long)rc);
        return;
    }
    s_ndspReady = true;

    FILE *f = fopen("romfs:/audio/bgm.pcm", "rb");
    if (!f) {
        snprintf(g_audioStatus, sizeof(g_audioStatus), "audio: arquivo nao achado");
        return;
    }

    fseek(f, 0, SEEK_END);
    long fileSize = ftell(f);
    fseek(f, 0, SEEK_SET);
    if (fileSize <= 0) {
        snprintf(g_audioStatus, sizeof(g_audioStatus), "audio: arquivo vazio");
        fclose(f); return;
    }

    s_bgmBuffer = (s16 *)linearAlloc((size_t)fileSize);
    if (!s_bgmBuffer) {
        snprintf(g_audioStatus, sizeof(g_audioStatus), "audio: linearAlloc falhou (%ld B)", fileSize);
        fclose(f); return;
    }

    size_t readBytes = fread(s_bgmBuffer, 1, (size_t)fileSize, f);
    fclose(f);
    if (readBytes != (size_t)fileSize) {
        snprintf(g_audioStatus, sizeof(g_audioStatus), "audio: leitura incompleta");
        linearFree(s_bgmBuffer);
        s_bgmBuffer = NULL;
        return;
    }

    s_bgmSamples = (u32)(fileSize / sizeof(s16));
    DSP_FlushDataCache(s_bgmBuffer, (u32)fileSize);

    ndspChnReset(BGM_CHANNEL);
    ndspChnSetInterp(BGM_CHANNEL, NDSP_INTERP_LINEAR);
    ndspChnSetRate(BGM_CHANNEL, BGM_SAMPLE_RATE);
    ndspChnSetFormat(BGM_CHANNEL, NDSP_FORMAT_MONO_PCM16);

    float mix[12];
    memset(mix, 0, sizeof(mix));
    mix[0] = 0.55f; /* front-left  */
    mix[1] = 0.55f; /* front-right */
    ndspChnSetMix(BGM_CHANNEL, mix);

    memset(&s_bgmWaveBuf, 0, sizeof(s_bgmWaveBuf));
    s_bgmWaveBuf.data_vaddr = s_bgmBuffer;
    s_bgmWaveBuf.nsamples   = s_bgmSamples;
    s_bgmWaveBuf.looping    = true;

    s_bgmReady = true;
    snprintf(g_audioStatus, sizeof(g_audioStatus), "audio: ok (%lu samples)", (unsigned long)s_bgmSamples);
}

void audio_play_bgm(void)
{
    if (!s_bgmReady) return;
    ndspChnWaveBufAdd(BGM_CHANNEL, &s_bgmWaveBuf);
}

void audio_stop_bgm(void)
{
    if (!s_ndspReady) return;
    ndspChnWaveBufClear(BGM_CHANNEL);
}

void audio_exit(void)
{
    if (s_ndspReady) {
        ndspChnWaveBufClear(BGM_CHANNEL);
    }
    if (s_bgmBuffer) {
        linearFree(s_bgmBuffer);
        s_bgmBuffer = NULL;
    }
    if (s_ndspReady) {
        ndspExit();
        s_ndspReady = false;
    }
}
