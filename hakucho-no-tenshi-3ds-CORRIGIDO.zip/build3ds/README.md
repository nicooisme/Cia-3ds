# 白鳥の天使 — Hakuchou no Tenshi (3DS nativo)

Jogo de "guerra de tinta" estilo Splatoon, feito para rodar nativamente no
Nintendo 3DS (Old 3DS incluso) usando **libctru + citro2d**.

Tela de cima: a ilha nevada inteira, sempre visível, com os 4 personagens
(você + 1 aliado bot vs 2 bots inimigos) pintando o território.
Tela de baixo: suas 5 vidas (corações), cronômetro e placar Laranja×Azul.

> ⚠️ **Importante e honesto:** este código foi escrito e revisado com
> cuidado seguindo a estrutura padrão de projetos devkitARM/citro2d, mas eu
> **não tenho como compilar nem testar num 3DS/emulador real** neste
> ambiente (sandbox sem a toolchain). É bem possível que, na primeira
> tentativa de `make`, apareçam pequenos erros de compilação — é normal em
> qualquer projeto homebrew escrito "a seco". Se aparecer algum erro, **cole
> a mensagem aqui que eu te ajudo a corrigir.**

## O que está pronto (v1 + atualização)
- Ilha **maior que a tela**, com câmera seguindo o personagem e zoom 2x
  (antes era a ilha inteira numa tela só — agora ela rola/segue você).
- Estética rosa com bolinhas (polka dots) nos menus, HUD e telas de
  título/fim — o terreno da ilha (neve/grama/pedra/água) continua como
  estava, só a "moldura"/UI ficou nesse visual.
- Corações de vida bem maiores na tela de baixo.
- Sem aura/anel de time — agora o **cabelo** (presente em todos os
  personagens, jogador e bots) é tingido na cor pastel do time e é isso
  que identifica quem é de qual lado.
- Cabelo e roupa **obrigatórios** (nunca "nenhum") — controles na tela de
  **Personalizar** (SELECT no título abre/fecha ela): **A** troca cabelo,
  **B** troca a pele/personagem, **Y** troca a roupa.
- **Água machuca**: encostar gera -1 hp na hora e te teleporta pro spawn
  do seu time (antes era parede sólida, agora dá pra entrar mas custa).
- **X pausa o jogo** a qualquer momento; na pausa, **SELECT** sai direto
  pra tela de Personalizar (abandona a partida atual).
- **Bots 35% mais rápidos** que o jogador.
- Cores de time em tom **pastel** (laranja e azul suaves) em vez do tom
  saturado de antes.
- **Fonte KiwiSoda** (pixel font) nos textos, convertida `.ttf`→`.bcfnt` via
  `mkbcfnt` (mesmo projeto do `tex3ds`). Se essa ferramenta não existir na
  sua imagem Docker, o jogo cai pra fonte padrão do sistema automaticamente.
- Animação idle (8 frames, agora anima mesmo parado) e andar (2 frames)
  com os papéis corrigidos.
- **Música de fundo** (NDSP/libctru), convertida do mp3 que você mandou pra
  PCM cru mono 22050Hz (~7MB), tocando em loop desde a tela de título.
- Geração da ilha (água / grama / pedra / neve), sistema de tinta em grid,
  4 personagens animados, IA simples dos 3 bots, vida em 5 corações,
  controle por Circle Pad (pinta sozinho ao andar), START começa/reinicia.

## Sobre a música de fundo
O arquivo `romfs/audio/bgm.pcm` foi gerado a partir do mp3 que você enviou
(`ffmpeg -ar 22050 -ac 1 -f s16le`). É reproduzido via NDSP em loop contínuo,
volume moderado, começando assim que o jogo abre. **Nota sobre direitos
autorais:** isso é apropriado para uso pessoal no seu próprio `.cia`/3DS; se
um dia você for compartilhar o arquivo com outras pessoas, vale lembrar que
a música tem direitos do artista original.

## O que ficou de fora por agora (próximos passos)
- Acessórios separados de roupa (o pack que você mandou só tinha uma pasta
  combinada "roupas" — se quiser, dá pra puxar óculos/estrela/pulseira dos
  uploads originais como uma categoria extra).
- Filtro de cor automático no cabelo por time (hoje é decorativo, sem tint).
- Sem chat / sem IA de linguagem nos bots (jogam por lógica local).


## Como compilar

1. Instale o **devkitPro** oficial (não é o GitHub — é o instalador deles):
   https://devkitpro.org/wiki/Getting_Started
   Marque os pacotes `3ds-dev` durante a instalação (inclui devkitARM,
   libctru, citro2d/citro3d, tex3ds).

2. Abra um terminal com o ambiente devkitPro carregado e confirme:
   ```bash
   echo $DEVKITARM
   ```
   (deve apontar para a pasta `devkitARM` dentro da instalação)

3. Dentro da pasta do projeto:
   ```bash
   make
   ```
   Isso gera `hakucho-no-tenshi.3dsx` (+ `.smdh`) — já roda via
   **Homebrew Launcher** num 3DS com CFW, ou no emulador **Citra/Azahar**.

## Gerando o `.3ds` (CCI) ou `.cia`

Isso precisa de **3 ferramentas** que NÃO vêm na imagem Docker `devkitpro/devkitarm`
(só o `tex3ds` vem) — precisam ser instaladas separadamente, no Mac/Linux/Codespace
que for empacotar o `.cia` (não dentro do Docker):

- **makerom**: binário pronto em https://github.com/3DSGuy/Project_CTR/releases
  (escolha o arquivo certo pro seu sistema: macOS Apple Silicon/Intel, ou
  `ubuntu_x86_64` se estiver num Codespace/Linux)
- **bannertool**: binário pronto em
  https://github.com/carstene1ns/3ds-bannertool/releases (linux/macOS fonte
  precisa compilar com cmake; no Mac também tem fonte compilável)
- **3dstool**: binário pronto em https://github.com/dnasdw/3dstool/releases
  (usado pra gerar o `romfs.bin` — sem isso o `.cia` fica sem nenhum gráfico/
  áudio embutido e o jogo crasha ao abrir!)

Depois de instalar os 3 (`makerom`, `bannertool`, `3dstool` no PATH):

```bash
bannertool makesmdh -i icon.png -s "Hakuchou no Tenshi" -l "Ink turf battle on a snowy island" -p "Voce" -o icon.icn
bannertool makebanner -i banner_src.png -a silence.wav -o banner.bnr
make
make cia       # já gera o romfs.bin automaticamente e empacota tudo
```

O `make cia` (e `make 3dscart`) já chamam o `3dstool` internamente antes do
`makerom`, então não precisa rodar esse passo à mão — só garanta que os 3
binários estão instalados e no PATH primeiro.

## Como instalar o `.cia` num 3DS de verdade

Isso só funciona em consoles com **homebrew habilitado** (Custom Firmware
como Luma3DS, ou ao menos o Homebrew Launcher com o app **FBI** instalado —
um 3DS de fábrica sem CFW não instala `.cia` não-assinado pela Nintendo).

**Se seu 3DS já tem CFW (Luma3DS) instalado:**
1. Copie o `hakucho-no-tenshi.cia` pra raiz do cartão SD (ex: via cabo USB
   ou leitor de cartão).
2. Abra o **FBI** no 3DS (geralmente no menu Homebrew Launcher, ou já
   instalado no HOME Menu se você usa CFW).
3. Dentro do FBI: `SD` → navegue até o arquivo `.cia` → **A** para
   selecionar → **Install CIA**.
4. O ícone do jogo aparece no HOME Menu normalmente, junto dos outros jogos.

**Se preferir instalar via rede (sem tirar o cartão SD):**
1. No 3DS, abra o FBI e ative o **Remote Install** (mostra um IP:porta na
   tela).
2. No PC, na mesma rede Wi-Fi:
   ```bash
   curl -T hakucho-no-tenshi.cia "ftp://IP_DO_3DS:PORTA/Bonjour.cia"
   ```
   (ou use o modo HTTP do FBI, que aceita um `curl --upload-file` direto pra
   URL mostrada na tela — os detalhes exatos variam um pouco por versão do
   FBI, a tela dele mostra o comando certo).

Se seu 3DS **não** tem homebrew habilitado ainda, o primeiro passo é
instalar o Homebrew Launcher (via algum exploit compatível com a versão do
seu sistema) antes de qualquer coisa acima — isso é específico do modelo e
versão do firmware, vale procurar um guia atualizado pro seu 3DS específico.

## Estrutura do projeto

```
Makefile          - build padrão devkitARM (.3dsx) + alvos opcionais cia/3dscart
basic.rsf         - spec do makerom p/ gerar .cia/.3ds
icon.png          - ícone do jogo (logo 白鳥の天使, redimensionada p/ 48x48)
include/game.h    - structs e constantes compartilhadas
source/main.c     - init, loop principal, máquina de estados (título/jogo/fim)
source/map.c      - geração da ilha + grid de tinta
source/entity.c   - movimento, IA dos bots, vida
source/hud.c      - desenho das duas telas
gfx/              - PNGs originais + .t3s (specs de spritesheet pro tex3ds)
```

Qualquer erro de compilação, manda a mensagem aqui que eu ajusto o código.
